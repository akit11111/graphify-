"""Markdown extractor. Moved verbatim from graphify/extract.py."""
from __future__ import annotations

import re
import os
import unicodedata

from pathlib import Path
from urllib.parse import unquote
from graphify.detect import CODE_EXTENSIONS, DOC_EXTENSIONS, classify_file
from graphify.extractors.base import _file_stem, _make_id, _read_source_text
from graphify.security import sanitize_metadata


# A link destination is either <bracketed>, the only CommonMark form that may
# contain spaces ([t](<My Note.md>)), or a bare run without whitespace. The
# bracketed form is tried first so a spaced name is captured whole instead of
# being cut at the first space; callers take whichever group matched. After the
# `>` it only accepts a CommonMark title ("..", '..' or (..) without a nested
# paren), so an unclosed `<` falls back to the bare form rather than swallowing
# the links that follow on the line.
_MD_INLINE_LINK_RE = re.compile(
    r'(?<!\!)\[[^\]]*\]\(\s*(?:'
    r'<([^<>\n]+)>\s*(?:"[^"\n]*"|\'[^\'\n]*\'|\([^()\n]*\))?\s*'
    r'|<?([^)\s>]+)>?(?:\s+[^)]*)?'
    r')\)')

_MD_REF_DEF_RE = re.compile(
    r'^\s{0,3}\[[^\]]+\]:\s*(?:<([^<>\n]+)>(?=\s*(?:["\'(]|$))|<?([^\s>]+)>?)')

_MD_WIKILINK_RE = re.compile(r'(?<!\!)\[\[([^\]|#]+?)(?:\\?\|[^\]]*|#[^\]]*)?\]\]')

_MD_LINKABLE_EXTS = {".md", ".mdx", ".qmd", ".markdown", ".rst", ".txt"}

# Inline code spans, single or double backtick delimited. Fenced blocks are
# skipped before this runs, so a span here is prose citing a symbol by name.
_MD_CODE_SPAN_RE = re.compile(r'(?<!`)(`+)(?!`)(.+?)(?<!`)\1(?!`)')

# The two mention grammars a code span can carry. A path-qualified mention
# (``src/pkg/mod.py::Widget::render``) names the defining file and a
# ``::``-separated symbol chain, exactly as pytest node ids and cite-lint
# citations do. A bare mention (``Widget``, ``render()``, ``pkg.Widget``) names
# a symbol with no file evidence, so it resolves only on a unique match; the
# dotted form keeps its qualifiers (``pkg``) as evidence the resolver checks.
_MD_PATH_MENTION_RE = re.compile(
    r'^([A-Za-z0-9_./\-]+\.[A-Za-z0-9]+)::([A-Za-z_]\w*(?:::[A-Za-z_]\w*)*)(?:\(\))?$'
)
_MD_BARE_MENTION_RE = re.compile(
    r'^(?:[A-Za-z_]\w*\.)*([A-Za-z_]\w*)(?:\(\))?$'
)

# An ATX heading (CommonMark): up to three spaces of indent (four is an indented
# code block), 1-6 `#`, then whitespace and the text. An optional closing run of
# `#` preceded by whitespace is not part of the text: `## Setup ##` is "Setup",
# while `## C#` and `## Trailing \#` keep their `#`.
_MD_ATX_HEADING_RE = re.compile(r'^ {0,3}(#{1,6})[ \t]+(.+)$')
_MD_ATX_CLOSING_RE = re.compile(r'(?:^|[ \t]+)#+[ \t]*$')

# A fenced code block line: a run of 3+ backticks or 3+ tildes, then the rest of
# the line (an info string on an opener). Leading whitespace is accepted at any
# depth, as before, so a fence inside a nested list item still counts.
_MD_FENCE_RE = re.compile(r'^\s*(`{3,}|~{3,})(.*)$')


def _fence_open(line: str) -> "tuple[str, int] | None":
    """(fence char, run length) when ``line`` opens a fenced code block.

    CommonMark: a backtick fence's info string may not contain a backtick, so
    a line that starts with an inline ```` ```code``` ```` span is prose, not a
    fence. Tilde fences have no such restriction.
    """
    m = _MD_FENCE_RE.match(line)
    if not m:
        return None
    run, rest = m.group(1), m.group(2)
    if run[0] == "`" and "`" in rest:
        return None
    return run[0], len(run)


def _fence_closes(line: str, fence: "tuple[str, int]") -> bool:
    """True when ``line`` closes the block opened by ``fence``.

    CommonMark: the closing run uses the opener's character, is at least as
    long, and carries nothing but whitespace after it. So ``` does not close a
    ~~~ block, ``` does not close a ```` block (the usual way a doc shows a
    fenced example), and ``` followed by text is content.
    """
    m = _MD_FENCE_RE.match(line)
    if not m:
        return False
    run, rest = m.group(1), m.group(2)
    return run[0] == fence[0] and len(run) >= fence[1] and not rest.strip()

# A YAML frontmatter block is only frontmatter when the opening `---` is the
# very first line of the file. A `---` further down is a horizontal rule and
# must not be mistaken for one. Bounded so a file that opens a fence and never
# closes it cannot swallow the whole document.
_MD_FRONTMATTER_CLOSE = ("---", "...")
_MD_FRONTMATTER_MAX_LINES = 200

# Flat `key: value` fallback, used only when PyYAML is unavailable. PyYAML is
# not a declared dependency of graphify (see manifest_ingest._parse_apm for the
# same defensive-import pattern), so the extractor must degrade rather than
# fail.
_MD_FM_SCALAR_RE = re.compile(r'^([A-Za-z0-9_][A-Za-z0-9_\-. ]*):\s*(.*)$')


def _split_frontmatter(lines: list[str]) -> tuple[list[str], int]:
    """Split leading YAML frontmatter off *lines*.

    Returns ``(frontmatter_lines, body_start_index)``. When the file has no
    frontmatter — the common case — returns ``([], 0)`` and the caller parses
    from line 0 exactly as before.
    """
    if not lines or lines[0].strip() != "---":
        return [], 0
    limit = min(len(lines), _MD_FRONTMATTER_MAX_LINES + 1)
    for i in range(1, limit):
        if lines[i].strip() in _MD_FRONTMATTER_CLOSE:
            return lines[1:i], i + 1
    # Unterminated fence: treat the `---` as ordinary content, not frontmatter.
    return [], 0


def _parse_frontmatter(fm_lines: list[str]) -> dict:
    """Parse frontmatter lines into a plain dict.

    Values are passed through ``sanitize_metadata`` by the caller, so nested
    dicts and lists survive (a review workflow's ``coherence_check:`` block,
    Obsidian ``aliases:``) while staying bounded and HTML-safe.
    """
    if not fm_lines:
        return {}
    text = "\n".join(fm_lines)
    try:
        import yaml
    except ImportError:
        return _parse_frontmatter_fallback(fm_lines)
    try:
        data = yaml.safe_load(text)
    except Exception:
        # Malformed YAML in one document must not fail the whole extraction.
        return _parse_frontmatter_fallback(fm_lines)
    return data if isinstance(data, dict) else {}


def _parse_frontmatter_fallback(fm_lines: list[str]) -> dict:
    """Flat `key: value` parser for when PyYAML is not installed.

    Nested blocks and list items are skipped rather than guessed at; the keys
    that matter for graph filtering (``type``, ``review_status``, ``title``)
    are flat scalars in practice.
    """
    out: dict = {}
    for raw in fm_lines:
        if not raw[:1].strip():
            continue  # indented -> belongs to a nested block, skip
        m = _MD_FM_SCALAR_RE.match(raw.strip())
        if not m:
            continue
        key, value = m.group(1).strip(), m.group(2).strip()
        if not value:
            continue  # a bare `key:` opens a nested block
        out[key] = value.strip('"\'')
    return out

# Vault-wide wikilink fallback. Obsidian-style vaults resolve a [[wikilink]]
# by vault-global filename lookup, not relative to the linking file, so a note
# in a subfolder linking [[hub]] reaches a root-level hub.md. The lexical
# sibling resolution below is correct when the target exists beside the
# source; when it does not, the reference edge kept an id derived from a
# nonexistent path, matched no node, and silently dropped at build time — the
# same lost-edge failure #1376 fixed for hub docs, reintroduced for every
# cross-folder vault link. The fallback consults a per-scan-root index of
# document files and only fires when the lexically resolved path does not
# exist, so non-vault corpora and resolvable relative links are untouched.
#
# Keyed by resolved scan root. extract() clears it at the start of each run
# (beside _WORKSPACE_PACKAGE_CACHE) so a serial rerun in one process sees
# files created since the last run; parallel workers are fresh processes.
_MD_LINK_INDEX_CACHE: "dict[str, dict[str, list[tuple[int, str, Path]]]]" = {}


# The in-flight scan root now lives on extractors.base (correct import
# direction: extract.py -> extractors/, never back), so a rename can no longer
# silently disable link resolution the way the old getattr(graphify.extract, …,
# None) could (#3666).
from graphify.extractors.base import active_scan_root as _active_scan_root


def _nfc(s: str) -> str:
    # Filesystems disagree on Unicode normalization (macOS decomposes, others
    # do not); a link typed in NFC must still find a file listed in NFD.
    return unicodedata.normalize("NFC", s)


def _build_link_index(root: Path) -> "dict[str, list[tuple[int, str, Path]]]":
    """Index every linkable document under *root* by NFC-normalized basename.

    Each entry maps basename -> [(depth, root-relative posix path, absolute
    path)]. Directories in detect._SKIP_DIRS, dot-directories, and paths
    excluded by .graphifyignore/.gitignore are pruned — the same corpus
    boundary the scanner draws, and Obsidian itself does not index dot-folders
    or ignored paths (#3822).
    """
    from graphify.detect import _SKIP_DIRS, ignored_predicate
    root = Path(root)
    ignored = ignored_predicate(root)
    index: dict[str, list[tuple[int, str, Path]]] = {}
    for dirpath, dirnames, filenames in os.walk(root):
        dp = Path(dirpath)
        dirnames[:] = sorted(
            d for d in dirnames
            if not d.startswith(".") and d not in _SKIP_DIRS and not ignored(dp / d)
        )
        for fname in filenames:
            if Path(fname).suffix.lower() not in _MD_LINKABLE_EXTS:
                continue
            abs_path = dp / fname
            if ignored(abs_path):
                continue
            rel = os.path.relpath(str(abs_path), str(root)).replace("\\", "/")
            index.setdefault(_nfc(fname), []).append(
                (rel.count("/"), _nfc(rel), abs_path)
            )
    return index


def _vault_lookup(target: str, root: Path) -> "Path | None":
    """Resolve *target* (a normalized wikilink path, `.md` already appended)
    against the corpus under *root*, or None when nothing matches.

    A bare name matches by basename; a path-qualified target
    (``folder/name.md``) must match its full segment suffix. Ties break to the
    shallowest match, then lexicographically — mirroring Obsidian, where a
    root-level file wins a bare-link name collision — so resolution is
    deterministic regardless of walk order.
    """
    root_key = str(root)
    index = _MD_LINK_INDEX_CACHE.get(root_key)
    if index is None:
        try:
            index = _build_link_index(root)
        except OSError:
            index = {}
        _MD_LINK_INDEX_CACHE[root_key] = index
    parts = _nfc(target.replace("\\", "/")).split("/")
    candidates = index.get(parts[-1])
    if not candidates:
        return None
    suffix = "/".join(parts)
    matches = [
        c for c in candidates
        if c[1] == suffix or c[1].endswith("/" + suffix)
    ]
    if not matches:
        # Obsidian writes vault-relative paths, so scanning a folder below the
        # vault root meets links that start with that folder's own path
        # ([[Corp/wiki/Fox]] from inside Corp/, #4559). Drop the longest such
        # leading run and match the rest from the scan root.
        root_parts = [_nfc(p) for p in Path(root).parts]
        for k in range(len(parts) - 1, 0, -1):
            if parts[:k] == root_parts[-k:]:
                rest = "/".join(parts[k:])
                matches = [c for c in candidates if c[1] == rest]
                break
    if not matches:
        return None
    return min(matches)[2]


def _percent_decoded(target: str, source_dir: Path) -> str:
    """Decode a URL-style link destination such as ``My%20Note.md``.

    Inline and reference links are URLs, so a space or a non-ASCII character
    in a file name is written percent-encoded (the form Obsidian writes when
    wikilinks are turned off). A file whose name literally contains the
    escape keeps precedence (``[x](100%25)`` beside ``100%25.md``), so a
    link that resolved before still resolves to the same file. Wikilinks
    carry the note name verbatim and never come through here.
    """
    if "%" not in target:
        return target
    decoded = unquote(target)
    if decoded == target:
        return target
    literal = target if Path(target).suffix else target + ".md"
    try:
        if (source_dir / literal).is_file():
            return target
    except OSError:
        pass
    return decoded


def _is_external_link(target: str) -> bool:
    low = target.lower()
    return "://" in target or low.startswith(("mailto:", "tel:", "//", "data:"))


def _resolve_markdown_link(raw: str, source_dir: Path,
                           wikilink: bool = False) -> "Path | None":
    """Resolve a markdown link target to the absolute path of a sibling document.

    Returns the resolved (normalized, not necessarily existing) path when the
    target is a *local* relative/absolute file-path link to a document, or None
    when it should be skipped: external URLs (http/https/mailto/protocol-
    relative/data), pure in-page anchors (``#section``), and links to non-doc
    file types (code/assets are handled by their own extractors).

    The anchor fragment (``#section``) and query (``?x=1``) are stripped before
    resolution so ``./repo.md#setup`` resolves to the same node as ``./repo.md``.
    Inline and reference destinations are percent-decoded (``My%20Note.md``),
    see _percent_decoded. Extension-less targets (typical of wikilinks) are
    treated as sibling ``.md``.
    A wikilink whose note name itself contains a dot (``[[note.en]]``,
    ``[[v1.2 release]]``) gets the same ``.md`` completion, but only when that
    document exists and no file graphify indexes sits at the literal target;
    otherwise (``[[image.png]]``) it stays skipped.

    With ``wikilink=True``, a target whose lexically resolved path does not
    exist is retried as a vault-global lookup across the active scan root (see
    _vault_lookup) — Obsidian's own resolution order for wikilinks. Inline and
    reference-style links keep pure relative semantics: for them a missing
    relative target is an authoring error, not an alternate link convention.
    """
    target = raw.strip()
    if not target:
        return None
    # Drop anchor / query so #section links still resolve to the target doc.
    target = target.split("#", 1)[0].split("?", 1)[0].strip()
    if not target:
        return None
    if _is_external_link(target):
        return None
    if not wikilink:
        # Decoding can reveal a scheme or a protocol-relative prefix
        # (%2F%2Fhost), so the external-link guard runs again.
        target = _percent_decoded(target, source_dir)
        if _is_external_link(target):
            return None
    suffix = Path(target).suffix.lower()
    if suffix == "":
        target = target + ".md"
        suffix = ".md"
    if suffix not in _MD_LINKABLE_EXTS:
        if not wikilink:
            return None
        # The suffix may be part of the note name ([[v1.2 release]]): try
        # <name>.md through the same sibling-then-vault resolution and keep
        # the link only when that document exists. A literal target graphify
        # indexes itself ([[pic.png]] beside pic.png.md) keeps precedence.
        literal = Path(os.path.normpath(str(source_dir / target)))
        try:
            if literal.is_file() and classify_file(literal) is not None:
                return None
            hit = _resolve_markdown_link(target + ".md", source_dir, wikilink=True)
            return hit if hit is not None and hit.is_file() else None
        except OSError:
            return None
    candidate = Path(target)
    if not candidate.is_absolute():
        candidate = source_dir / candidate
    resolved = Path(os.path.normpath(str(candidate)))
    if wikilink and not Path(target).is_absolute():
        try:
            missing = not resolved.is_file()
        except OSError:
            missing = False
        if missing:
            scan_root = _active_scan_root()
            if scan_root is not None:
                hit = _vault_lookup(target, scan_root)
                if hit is not None:
                    return Path(os.path.normpath(str(hit)))
    return resolved

def _code_span_mention(span: str) -> "tuple[str | None, list[str]] | None":
    """Classify one inline code span as a symbol mention, or None.

    Returns ``(path, names)``: ``path`` is the cited file for the
    ``path::Name`` form and None for a bare or dotted mention; ``names`` is the
    symbol chain, outermost first, so ``pkg.sub.Widget`` yields
    ``["pkg", "sub", "Widget"]`` and the resolver can hold the match to that
    evidence. A trailing ``()`` is dropped from the last name so ``render()``
    and ``render`` cite the same symbol. Spans that read as a file
    (``setup.py``, ``README.md``), a shell command, an expression or prose are
    not mentions and yield None.
    """
    text = span.strip()
    if not text or " " in text:
        return None
    m = _MD_PATH_MENTION_RE.match(text)
    if m:
        return m.group(1), m.group(2).split("::")
    m = _MD_BARE_MENTION_RE.match(text)
    if not m:
        return None
    if "." in text:
        # ``a.b.Name`` is a qualified symbol; ``setup.py`` and ``README.md``
        # are files. A dotted span whose last segment is a code or document
        # extension is the latter. Other file-like spans (``pyproject.toml``)
        # classify as a mention and are rejected at resolution, where the
        # qualifier ``pyproject`` matches no callable's file or owner.
        if "." + m.group(1) in CODE_EXTENSIONS or "." + m.group(1) in DOC_EXTENSIONS:
            return None
        return None, text.rstrip("()").split(".")
    return None, [m.group(1)]


def extract_markdown(path: Path) -> dict:
    """Extract structural nodes and edges from a Markdown file.

    Produces nodes for:
    - The file itself, tagged ``node_kind: "page"``, carrying any YAML
      frontmatter under ``frontmatter``
    - Each heading (# / ## / ### etc.), tagged ``node_kind: "heading"``

    ``node_kind`` exists because ``file_type`` cannot carry this distinction:
    it is a closed enum (build.py rewrites anything outside
    ``code|document|paper|image|rationale|concept`` to ``"concept"``) and
    ``"document"`` on both endpoints is load-bearing for the twin-merge pass.
    Without a separate field, headings — typically the large majority of nodes
    in a docs-heavy corpus — cannot be filtered out by a consumer.

    Produces edges for:
    - file --contains--> heading
    - parent heading --contains--> child heading (nesting by level)
    - file --references--> linked document, for inline ``[text](./other.md)``,
      reference-style ``[label]: ./other.md`` and ``[[wikilink]]`` links, so a
      hub doc (``index.md`` / ``table-of-contents.md``) becomes a real hub node
      instead of an under-connected orphan (#1376). The target node ID is built
      from the resolved target path with the same recipe as the target file's
      own node, so the edge merges into that node (no ghost node). External
      URLs, in-page anchors, images and non-document targets are skipped.

    Inline code spans on heading and body lines (backtick-quoted ``Widget``,
    ``render()``, ``pkg.Widget`` or ``src/mod.py::Widget::render``) are
    collected as ``raw_calls`` tagged ``language: "markdown"`` rather than
    edges: the symbol they cite lives in another file, so the match is made
    once every file is extracted and ids are final, by the
    ``markdown_mentions`` language resolver (see
    ``graphify.markdown_resolution``). The dotted form travels with its
    qualifiers, which the resolver checks against the match's owners and
    file path. That pass emits
    heading --references--> code symbol (page --references--> symbol for a
    mention above the first heading): EXTRACTED for the path-qualified form,
    INFERRED for a bare name that matches exactly one code symbol. The shared
    cross-file call pass skips these raw_calls, so a mention never becomes a
    ``calls`` edge.

    Fenced code blocks (``` ... ``` or ~~~ ... ~~~, closed by a run of the
    same character at least as long, per CommonMark) are skipped during
    parsing so their contents don't get treated as headings, but no node is emitted for
    them — they were always orphans (only a single contains edge to the
    parent doc) and inflated the disconnected-component count (#1077).

    Leading YAML frontmatter is parsed onto the page node and excluded from
    heading detection (a `#` there is a YAML comment). Links inside it are
    still followed: review workflows keep wikilinks in frontmatter and those
    are genuine references.

    No tree-sitter dependency — pure line-by-line parsing.
    """
    try:
        source = _read_source_text(path)
    except Exception as e:
        return {"nodes": [], "edges": [], "error": str(e)}

    stem = _file_stem(path)
    str_path = str(path)
    nodes: list[dict] = []
    edges: list[dict] = []
    raw_calls: list[dict] = []
    seen_ids: set[str] = set()
    seen_mentions: set[tuple[str, "str | None", tuple[str, ...]]] = set()

    def add_mention(caller_nid: str, span: str, line: int) -> None:
        mention = _code_span_mention(span)
        if mention is None:
            return
        cited_path, names = mention
        key = (caller_nid, cited_path, tuple(names))
        if key in seen_mentions:
            return
        seen_mentions.add(key)
        raw_call = {
            "caller_nid": caller_nid,
            "callee": names[-1],
            "is_member_call": False,
            "language": "markdown",
            "context": span.strip(),
            "source_file": str_path,
            "source_location": f"L{line}",
        }
        if cited_path is not None:
            raw_call["path"] = cited_path
        if len(names) > 1:
            raw_call["qualifiers"] = names[:-1]
        raw_calls.append(raw_call)

    def add_node(nid: str, label: str, line: int, file_type: str = "document",
                 node_kind: str = "heading", extra: "dict | None" = None) -> None:
        if nid not in seen_ids:
            seen_ids.add(nid)
            node = {"id": nid, "label": label, "file_type": file_type,
                    "node_kind": node_kind,
                    "source_file": str_path, "source_location": f"L{line}"}
            if extra:
                node.update(extra)
            nodes.append(node)

    def add_edge(src: str, tgt: str, relation: str, line: int,
                 confidence: str = "EXTRACTED", weight: float = 1.0,
                 target_file: "str | None" = None) -> None:
        edge = {"source": src, "target": tgt, "relation": relation,
                "confidence": confidence, "source_file": str_path,
                "source_location": f"L{line}", "weight": weight}
        if target_file is not None:
            edge["target_file"] = target_file
        edges.append(edge)

    lines = source.splitlines()
    fm_lines, body_start = _split_frontmatter(lines)
    frontmatter = sanitize_metadata(_parse_frontmatter(fm_lines))

    file_nid = _make_id(str(path))
    add_node(file_nid, path.name, 1, node_kind="page",
             extra={"frontmatter": frontmatter} if frontmatter else None)

    source_dir = path.parent
    # Dedup link edges by resolved target node so a hub doc that links to the
    # same sibling many times yields one edge, not N (keeps weights meaningful).
    linked_targets: set[str] = set()

    def add_link(raw: str, line: int, wikilink: bool = False) -> None:
        resolved = _resolve_markdown_link(raw, source_dir, wikilink=wikilink)
        if resolved is None:
            return
        # Build the target ID with the SAME recipe as the target file's own
        # node (_make_id(str(path)) at extract time, canonicalized to
        # _file_node_id(rel) by the extract() post-pass). Using the absolute
        # resolved path means both endpoints get remapped identically, so the
        # edge merges into the existing doc node instead of spawning a ghost.
        tgt_nid = _make_id(str(resolved))
        if tgt_nid == file_nid or tgt_nid in linked_targets:
            return
        linked_targets.add(tgt_nid)
        # Stamp the resolved target file (mirroring the JS/Python import
        # stamps, #1814/#2213) so the #2169 remap pass can canonicalize this
        # edge's target on an incremental run where the linked doc is not in
        # the batch — without it the target keeps an absolute-path-derived id
        # that matches no node in the merged graph and the md->md reference
        # silently drops (#2211). Existence-gated: a link to a nonexistent
        # doc must stay dangling, exactly as before. The stamp is transient
        # and popped before graph.json ships.
        target_file = None
        try:
            if resolved.is_file():
                target_file = str(resolved)
        except OSError:
            pass
        add_edge(file_nid, tgt_nid, "references", line, target_file=target_file)

    # Track heading stack for nesting: [(level, nid), ...]
    heading_stack: list[tuple[int, str]] = []
    fence: "tuple[str, int] | None" = None  # (char, length) of the open fence

    for line_num_0, line_text in enumerate(lines):
        line_num = line_num_0 + 1

        # Skip over fenced code blocks so their contents are not parsed as
        # headings, but do not emit nodes/edges for them (#1077).
        if fence is not None:
            if _fence_closes(line_text, fence):
                fence = None
            continue
        opened = _fence_open(line_text)
        if opened is not None:
            fence = opened
            continue

        # Markdown links -> document references (#1376). Scanned on every
        # non-fenced line (including heading lines, which the heading branch
        # below `continue`s past) so links anywhere in the doc are captured.
        for m in _MD_INLINE_LINK_RE.finditer(line_text):
            add_link(m.group(1) or m.group(2), line_num)
        for m in _MD_WIKILINK_RE.finditer(line_text):
            add_link(m.group(1), line_num, wikilink=True)
        ref_def = _MD_REF_DEF_RE.match(line_text)
        if ref_def:
            add_link(ref_def.group(1) or ref_def.group(2), line_num)

        # Inside the frontmatter block a leading `#` is a YAML comment, not an
        # H1. Links above are still scanned there on purpose: review workflows
        # put wikilinks in frontmatter (e.g. a `consulted:` list), and those are
        # real references. Only heading detection is suppressed.
        if line_num_0 < body_start:
            continue

        # Detect headings: # Heading, ## Heading, etc.
        heading_match = _MD_ATX_HEADING_RE.match(line_text)
        title = _MD_ATX_CLOSING_RE.sub("", heading_match.group(2).strip()) if heading_match else ""
        if heading_match and title:
            level = len(heading_match.group(1))
            h_nid = _make_id(stem, title)
            # Avoid duplicate heading IDs by appending line number
            if h_nid in seen_ids:
                h_nid = _make_id(stem, title, str(line_num))
            add_node(h_nid, title, line_num)

            # Pop headings at same or deeper level
            while heading_stack and heading_stack[-1][0] >= level:
                heading_stack.pop()

            # Connect to parent heading or file
            parent = heading_stack[-1][1] if heading_stack else file_nid
            add_edge(parent, h_nid, "contains", line_num)

            heading_stack.append((level, h_nid))
            # A code span in the heading itself is that heading's mention.
            for m in _MD_CODE_SPAN_RE.finditer(title):
                add_mention(h_nid, m.group(2), line_num)
            continue

        # Body prose: a code span cites a symbol on behalf of the enclosing
        # heading (the page when the text precedes the first heading).
        owner = heading_stack[-1][1] if heading_stack else file_nid
        for m in _MD_CODE_SPAN_RE.finditer(line_text):
            add_mention(owner, m.group(2), line_num)

    return {"nodes": nodes, "edges": edges, "raw_calls": raw_calls,
            "input_tokens": 0, "output_tokens": 0}
